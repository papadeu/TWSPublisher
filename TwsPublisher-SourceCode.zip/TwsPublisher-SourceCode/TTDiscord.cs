using System.Text;
using Newtonsoft.Json;

namespace TwsPublisher
{
    internal class TTDiscord
    {
        public TTDiscord() { }

        private static HttpClient client;
        public static HttpClient Client
        {
            get
            {
                if (client == null)
                    client = new HttpClient();

                return client;
            }
        }

        public static async Task SendToDiscord(string webhookUrl, string message)
        {

            var SuccessWebHook = new
            {
                content = message, //"This is the main content section",
            };


            string EndPoint = webhookUrl;

            var content = new StringContent(JsonConvert.SerializeObject(SuccessWebHook), Encoding.UTF8, "application/json");

            await Client.PostAsync(EndPoint, content);

        }
    }
}
