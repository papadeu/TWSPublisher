using System.Configuration;
using IBApi;

namespace TwsPublisher
{
    public partial class Publisher : Form
    {
        InterBroker _broker = null;

        string _phOpen = string.Empty;
        string _phClose = string.Empty;
        string _phRemain = "% of last reference size in cons amount";
        string _phDefaultSize = "% of default $ size";
        decimal _defaultPositionValue = 10000;
        Dictionary<string, KeyValuePair<IBApi.Messages.UpdatePortfolioMessage, decimal>> _positions = new Dictionary<string, KeyValuePair<IBApi.Messages.UpdatePortfolioMessage, decimal>>();
        string _disclaimerText = string.Empty;

        public Publisher()
        {
            InitializeComponent();
        }

        string _account = string.Empty;
        Action<IBApi.Messages.UpdatePortfolioMessage> handlerUpdatePositions = null;

        private async void Form1_Load(object sender, EventArgs e)
        {
            SetTooltips();

            this.FormClosing += Publisher_FormClosing;
            ReadAppSettings();

            handlerUpdatePositions = HandlePositionUpdate;

            //bool startDirectly = false;
            //bool.TryParse(ConfigurationManager.AppSettings["StartDirectly"], out startDirectly);
            //checkBoxStart.Checked = startDirectly;

            //if(startDirectly)
            await ConnectToIbkr();

        }

        private void SetTooltips()
        {
            ToolTip toolTip = new ToolTip();
            toolTip.SetToolTip(labelConnection, "If no connection, check account number, port id or TWS File-GlobalConfiguration-API" + Environment.NewLine + "After change restart this program again.");

            string infoDefaultSize = "Usually used trade size for master account in given period." + Environment.NewLine + "It will help to calculate the % of the used size in specific transactions if they deviate from the nominal amount at some days (e.g. Friday)";
            toolTip.SetToolTip(textBoxDefaultTradeSize, infoDefaultSize);
            toolTip.SetToolTip(labelDefaultSize, infoDefaultSize);
        }

        async Task ConnectToIbkr()
        {
            _phOpen = textBoxOpenText.Text.Trim();
            _phClose = textBoxCloseText.Text.Trim();
            _disclaimerText = textBoxDisclaimer.Text.Trim();
            decimal.TryParse(textBoxDefaultTradeSize.Text.Trim(), out _defaultPositionValue);

            _account = textBoxIBKRAccountID.Text.Trim();

            if (_broker != null && _broker.IsConnected)
            {
                _broker.UnsubscribeFromPositions(_account);
                _broker.Disconnect();
            }

            int port = 0;
            int.TryParse(textBoxIBKRPort.Text.Trim(), out port);
            _broker = new InterBroker
            {
                Port = port,
                Timeout = TimeSpan.FromSeconds(5)
            };


            var id = await _broker.Connect();

            // Subscriptions
            _broker.SubscribeToPositions(_account, handlerUpdatePositions);

            string connectionText = _broker.IsConnected ? "connected" : "not connected";
            Color connectionColor = _broker.IsConnected ? Color.Green : Color.Red;
            Color backColor = _broker.IsConnected ? SystemColors.Control : Color.FromArgb(255, 255, 192);
            if (labelConnection.InvokeRequired)
            {
                labelConnection.BeginInvoke((MethodInvoker)(() => { labelConnection.Text = connectionText; }));
                labelConnection.BeginInvoke((MethodInvoker)(() => { labelConnection.ForeColor = connectionColor; }));
                labelConnection.BeginInvoke((MethodInvoker)(() => { this.BackColor = backColor; }));
            }
            else
            {
                labelConnection.Text = connectionText;
                labelConnection.ForeColor = connectionColor;
                this.BackColor = backColor;
            }
        }
        //async Task DisconnectFromIbkr()
        //{
        //    _broker.UnsubscribeFromPositions(_account);
        //    _broker.Disconnect();
        //    _broker = null;
        //}
        
        void HandlePositionUpdate(IBApi.Messages.UpdatePortfolioMessage o)
        {
            string triggeredSymbol = o.Contract.LocalSymbol;
            var currentPosition = _positions.FirstOrDefault(x => x.Value.Key.Contract.LocalSymbol == triggeredSymbol && x.Value.Key.AccountName == _account);
            if (currentPosition.Key != null && currentPosition.Value.Key.Position != o.Position)
            {
                decimal diff = o.Position - currentPosition.Value.Key.Position;
                if (o.Position == 0)
                {
                    //all closed
                    if (_positions.Keys.Contains(triggeredSymbol))
                        _positions.Remove(triggeredSymbol);

                    //closed % of remaining cons amount
                    var percentageClosed = Math.Round((diff / currentPosition.Value.Value) * 100, 0);
                    SendMessage($"{_phClose} STC {triggeredSymbol} | {percentageClosed} {_phRemain} | no more items |", diff);
                }
                else
                {
                    bool sold = diff < 0;
                    if (sold && currentPosition.Value.Key.Position > 0)
                    {
                        //closed % of remaining cons amount
                        var percentageClosed = Math.Round((diff / currentPosition.Value.Value) * 100, 0);
                        SendMessage($"{_phClose} STC {triggeredSymbol} | {percentageClosed} {_phRemain} |", diff);
                    }
                    else if (!sold) //bought
                    {
                        decimal currentAmount = o.Position; //take the real size after BTO
                        int muliplier = o.Contract.SecType.ToUpper() == "OPT" ? 100 : 1;
                        var boughtValue = diff * (decimal)currentPosition.Value.Key.MarketPrice * muliplier;
                        var boughtPercenageOfDefSize = Math.Round((boughtValue / _defaultPositionValue) * 100, 0);//opened % of default $ size

                        _positions[triggeredSymbol] = new KeyValuePair<IBApi.Messages.UpdatePortfolioMessage, decimal>(o, currentAmount);

                        string overallSize = $"New reference size is {boughtPercenageOfDefSize} % of default $ size";

                        if (currentAmount > diff) //averaging
                        {
                            var overallAmount = o.AverageCost * (double)currentAmount;
                            var oberallPercentageOfDefSize = Math.Round((overallAmount / (double)_defaultPositionValue) * 100, 0);//opened % of default $ size
                            overallSize = $"New reference size is {oberallPercentageOfDefSize} % of default $ size";
                        }

                        SendMessage($"{_phOpen} BTO {triggeredSymbol} | {boughtPercenageOfDefSize} {_phDefaultSize} | {overallSize} |", diff);
                    }
                }
            }

            if (_positions.Keys.Contains(triggeredSymbol))
                _positions[triggeredSymbol] = new KeyValuePair<IBApi.Messages.UpdatePortfolioMessage, decimal>(o, _positions[triggeredSymbol].Value);
            else
                _positions[triggeredSymbol] = new KeyValuePair<IBApi.Messages.UpdatePortfolioMessage, decimal>(o, o.Position);


        }


        private void SendMessage(string text, decimal diff)
        {
            try
            {
                var msg = Environment.NewLine + text.Trim() + Environment.NewLine + _disclaimerText + Environment.NewLine;

                if (checkBoxWebhook.Checked)
                {
                    string separatorDiscord = Convert.ToString((int)Math.Round(Math.Abs(diff)),2).PadLeft(10, '0').Replace("1", "*-*").Replace("0", "-");
                    TTDiscord.SendToDiscord(textBoxDiscordWebhook.Text.Trim(), msg + separatorDiscord);
                }

                void Update()
                {
                    richTextBoxOutput.AppendText(msg + "----------");
                }

                if (richTextBoxOutput.InvokeRequired)
                    richTextBoxOutput.BeginInvoke((Action)Update);
                else
                    Update();
            }
            catch (Exception ex)
            { MessageBox.Show("Error by message receiving. Please take screenshot and restart this application.\n " + ex.ToString()); }
        }

        private void Publisher_FormClosing(object? sender, FormClosingEventArgs e)
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.AppSettings.Settings["IBKRAccountId"].Value = textBoxIBKRAccountID.Text.Trim();
            config.AppSettings.Settings["TWSPort"].Value = textBoxIBKRPort.Text.Trim();
            config.AppSettings.Settings["DefaultTradeSizeUSD"].Value = textBoxDefaultTradeSize.Text.Trim();
            config.AppSettings.Settings["TextForOpen"].Value = textBoxOpenText.Text.Trim();
            config.AppSettings.Settings["TextForClose"].Value = textBoxCloseText.Text.Trim();
            config.AppSettings.Settings["DisclaimerText"].Value = textBoxDisclaimer.Text.Trim();
            config.AppSettings.Settings["DiscordWebHook"].Value = textBoxDiscordWebhook.Text.Trim();

            //config.AppSettings.Settings["StartDirectly"].Value = checkBoxStart.Checked.ToString();
            config.AppSettings.Settings["SendToDiscord"].Value = checkBoxWebhook.Checked.ToString();

            config.Save();

            this.FormClosing -= Publisher_FormClosing;

            // Disconnect from IBKR
            _broker?.Disconnect();
        }

        private void ReadAppSettings()
        {
            textBoxIBKRAccountID.Text = ConfigurationManager.AppSettings["IBKRAccountId"];
            textBoxIBKRPort.Text = ConfigurationManager.AppSettings["TWSPort"];
            textBoxDefaultTradeSize.Text = ConfigurationManager.AppSettings["DefaultTradeSizeUSD"];
            textBoxOpenText.Text = ConfigurationManager.AppSettings["TextForOpen"];
            textBoxCloseText.Text = ConfigurationManager.AppSettings["TextForClose"];
            textBoxDisclaimer.Text = ConfigurationManager.AppSettings["DisclaimerText"];
            textBoxDiscordWebhook.Text = ConfigurationManager.AppSettings["DiscordWebHook"];
           
        }
       
    }
}
