namespace TwsPublisher
{
    partial class Publisher
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Publisher));
            richTextBoxOutput = new RichTextBox();
            labelConnection = new Label();
            textBoxIBKRPort = new TextBox();
            label6 = new Label();
            textBoxIBKRAccountID = new TextBox();
            label3 = new Label();
            textBoxOpenText = new TextBox();
            label1 = new Label();
            textBoxCloseText = new TextBox();
            label2 = new Label();
            textBoxDiscordWebhook = new TextBox();
            label4 = new Label();
            checkBoxWebhook = new CheckBox();
            textBoxDisclaimer = new TextBox();
            label5 = new Label();
            textBoxDefaultTradeSize = new TextBox();
            labelDefaultSize = new Label();
            SuspendLayout();
            // 
            // richTextBoxOutput
            // 
            richTextBoxOutput.Location = new Point(12, 291);
            richTextBoxOutput.Name = "richTextBoxOutput";
            richTextBoxOutput.Size = new Size(884, 239);
            richTextBoxOutput.TabIndex = 1;
            richTextBoxOutput.Text = "";
            // 
            // labelConnection
            // 
            labelConnection.AutoSize = true;
            labelConnection.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            labelConnection.ForeColor = Color.Red;
            labelConnection.Location = new Point(33, 9);
            labelConnection.Name = "labelConnection";
            labelConnection.Size = new Size(109, 20);
            labelConnection.TabIndex = 19;
            labelConnection.Text = "not connected";
            // 
            // textBoxIBKRPort
            // 
            textBoxIBKRPort.Location = new Point(559, 49);
            textBoxIBKRPort.Margin = new Padding(3, 4, 3, 4);
            textBoxIBKRPort.Name = "textBoxIBKRPort";
            textBoxIBKRPort.Size = new Size(129, 27);
            textBoxIBKRPort.TabIndex = 38;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(469, 52);
            label6.Name = "label6";
            label6.Size = new Size(69, 20);
            label6.TabIndex = 37;
            label6.Text = "TWS Port";
            // 
            // textBoxIBKRAccountID
            // 
            textBoxIBKRAccountID.Location = new Point(193, 49);
            textBoxIBKRAccountID.Margin = new Padding(3, 4, 3, 4);
            textBoxIBKRAccountID.Name = "textBoxIBKRAccountID";
            textBoxIBKRAccountID.Size = new Size(233, 27);
            textBoxIBKRAccountID.TabIndex = 32;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(33, 56);
            label3.Name = "label3";
            label3.Size = new Size(115, 20);
            label3.TabIndex = 31;
            label3.Text = "IBKR Account Id";
            // 
            // textBoxOpenText
            // 
            textBoxOpenText.Location = new Point(193, 84);
            textBoxOpenText.Margin = new Padding(3, 4, 3, 4);
            textBoxOpenText.Name = "textBoxOpenText";
            textBoxOpenText.Size = new Size(233, 27);
            textBoxOpenText.TabIndex = 41;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(33, 91);
            label1.Name = "label1";
            label1.Size = new Size(97, 20);
            label1.TabIndex = 40;
            label1.Text = "Text for open";
            // 
            // textBoxCloseText
            // 
            textBoxCloseText.Location = new Point(559, 91);
            textBoxCloseText.Margin = new Padding(3, 4, 3, 4);
            textBoxCloseText.Name = "textBoxCloseText";
            textBoxCloseText.Size = new Size(337, 27);
            textBoxCloseText.TabIndex = 43;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(442, 91);
            label2.Name = "label2";
            label2.Size = new Size(97, 20);
            label2.TabIndex = 42;
            label2.Text = "Text for close";
            // 
            // textBoxDiscordWebhook
            // 
            textBoxDiscordWebhook.Location = new Point(193, 242);
            textBoxDiscordWebhook.Margin = new Padding(3, 4, 3, 4);
            textBoxDiscordWebhook.Name = "textBoxDiscordWebhook";
            textBoxDiscordWebhook.Size = new Size(703, 27);
            textBoxDiscordWebhook.TabIndex = 45;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(33, 242);
            label4.Name = "label4";
            label4.Size = new Size(130, 20);
            label4.TabIndex = 44;
            label4.Text = "Discord WebHook";
            // 
            // checkBoxWebhook
            // 
            checkBoxWebhook.AutoSize = true;
            checkBoxWebhook.Location = new Point(22, 201);
            checkBoxWebhook.Name = "checkBoxWebhook";
            checkBoxWebhook.Size = new Size(135, 24);
            checkBoxWebhook.TabIndex = 46;
            checkBoxWebhook.Text = "Send to discord";
            checkBoxWebhook.UseVisualStyleBackColor = true;
            // 
            // textBoxDisclaimer
            // 
            textBoxDisclaimer.Location = new Point(193, 126);
            textBoxDisclaimer.Margin = new Padding(3, 4, 3, 4);
            textBoxDisclaimer.Name = "textBoxDisclaimer";
            textBoxDisclaimer.Size = new Size(703, 27);
            textBoxDisclaimer.TabIndex = 48;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(33, 126);
            label5.Name = "label5";
            label5.Size = new Size(108, 20);
            label5.TabIndex = 47;
            label5.Text = "Disclaimer text";
            // 
            // textBoxDefaultTradeSize
            // 
            textBoxDefaultTradeSize.Location = new Point(193, 162);
            textBoxDefaultTradeSize.Margin = new Padding(3, 4, 3, 4);
            textBoxDefaultTradeSize.Name = "textBoxDefaultTradeSize";
            textBoxDefaultTradeSize.Size = new Size(233, 27);
            textBoxDefaultTradeSize.TabIndex = 50;
            // 
            // labelDefaultSize
            // 
            labelDefaultSize.AutoSize = true;
            labelDefaultSize.Location = new Point(33, 162);
            labelDefaultSize.Name = "labelDefaultSize";
            labelDefaultSize.Size = new Size(154, 20);
            labelDefaultSize.TabIndex = 49;
            labelDefaultSize.Text = "Default trade size in $";
            // 
            // Publisher
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 255, 192);
            ClientSize = new Size(908, 542);
            Controls.Add(textBoxDefaultTradeSize);
            Controls.Add(labelDefaultSize);
            Controls.Add(textBoxDisclaimer);
            Controls.Add(label5);
            Controls.Add(checkBoxWebhook);
            Controls.Add(textBoxDiscordWebhook);
            Controls.Add(label4);
            Controls.Add(textBoxCloseText);
            Controls.Add(label2);
            Controls.Add(textBoxOpenText);
            Controls.Add(label1);
            Controls.Add(textBoxIBKRPort);
            Controls.Add(label6);
            Controls.Add(textBoxIBKRAccountID);
            Controls.Add(label3);
            Controls.Add(labelConnection);
            Controls.Add(richTextBoxOutput);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Publisher";
            Text = "Tws Discord Publisher";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private RichTextBox richTextBoxOutput;
        private Label labelConnection;
        private TextBox textBoxIBKRPort;
        private Label label6;
        private TextBox textBoxIBKRAccountID;
        private Label label3;
        private TextBox textBoxOpenText;
        private Label label1;
        private TextBox textBoxCloseText;
        private Label label2;
        private TextBox textBoxDiscordWebhook;
        private Label label4;
        private CheckBox checkBoxWebhook;
        private TextBox textBoxDisclaimer;
        private Label label5;
        private TextBox textBoxDefaultTradeSize;
        private Label labelDefaultSize;
    }
}
